<?php
// KRYTEX: заявка с формы «Бесплатный осмотр» -> строка в _leads.php (читать: leads.php?k=...)
date_default_timezone_set('Asia/Almaty');
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') { http_response_code(405); exit('{}'); }
$raw = file_get_contents('php://input', false, null, 0, 4000);
$d = json_decode($raw, true);
if (!is_array($d)) $d = $_POST;
$f = function ($k, $n = 120) use ($d) {
  $v = isset($d[$k]) ? (string)$d[$k] : '';
  $v = preg_replace('/[\x00-\x1F\x7F]+/u', ' ', $v);
  return mb_substr(trim($v), 0, $n);
};
if ($f('hp') !== '') exit('{"ok":true}');               // honeypot for bots
$row = [date('Y-m-d H:i:s'), $f('name'), $f('car'), $f('service'), $f('src', 40), $f('gclid', 200), $f('page', 200)];
if ($row[1] === '' && $row[2] === '') exit('{"ok":false}');
$file = __DIR__ . '/_leads.php';
if (!file_exists($file)) file_put_contents($file, "<?php http_response_code(404); exit; ?>\n");
if (filesize($file) > 5000000) exit('{"ok":false}');
file_put_contents($file, json_encode($row, JSON_UNESCAPED_UNICODE) . "\n", FILE_APPEND | LOCK_EX);
echo '{"ok":true}';
