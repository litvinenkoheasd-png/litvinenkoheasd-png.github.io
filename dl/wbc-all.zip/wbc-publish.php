<?php
// wbcagency.kz: публикация блога «Советы» ботом. POST zip (поле "zip") с заголовком X-Key.
// Пишет ТОЛЬКО sovety/index.html, sovety/<slug>/index.html и wbc-sitemap.xml. Хранится хэш ключа.
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
header('X-Robots-Tag: noindex, nofollow');
if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST' || !hash_equals('d0bed5e30aa71613e6ab348fd9aefabdbc70d6f8fa9013b0961164be2151f55b', hash('sha256', (string)($_SERVER['HTTP_X_KEY'] ?? '')))) { http_response_code(404); exit; }
$up = $_FILES['zip']['tmp_name'] ?? '';
if (!$up || !is_uploaded_file($up) || filesize($up) > 5000000) exit('{"ok":false,"err":"no zip"}');
$z = new ZipArchive();
if ($z->open($up) !== true) exit('{"ok":false,"err":"bad zip"}');
$root = __DIR__; $done = []; $skip = [];
for ($i = 0; $i < $z->numFiles && $i < 500; $i++) {
  $n = $z->getNameIndex($i);
  if (substr($n, -1) === '/') continue;
  $ok = preg_match('#^sovety/(?:[a-z0-9]+(?:-[a-z0-9]+)*/)?index\.html$#', $n) || $n === 'wbc-sitemap.xml';
  $c = $ok ? $z->getFromIndex($i) : false;
  if ($c === false || strlen($c) > 400000 || stripos($c, '<?php') !== false || stripos($c, '<?=') !== false) { $skip[] = $n; continue; }
  if ($n === 'wbc-sitemap.xml' ? strpos($c, '<urlset') === false : stripos($c, '<!DOCTYPE html>') !== 0) { $skip[] = $n; continue; }
  $dst = $root . '/' . $n; $dir = dirname($dst);
  if (!is_dir($dir)) mkdir($dir, 0755, true);
  $tmp = $dst . '.tmp'; file_put_contents($tmp, $c); chmod($tmp, 0644); rename($tmp, $dst);
  $done[] = $n;
}
$z->close();
@file_put_contents($root . '/../wbc-data/publish.log', date('c') . ' ' . count($done) . ' ' . implode(',', $done) . "\n", FILE_APPEND);
echo json_encode(['ok' => true, 'written' => $done, 'skipped' => $skip], JSON_UNESCAPED_UNICODE);
