<?php
// wbcagency.kz: заявка со страниц городов без своих мастеров (Алматы, Караганда) -> строка в _wbc_leads.php (читать: wbc-leads.php?k=...)
date_default_timezone_set('Asia/Almaty');
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') { http_response_code(405); exit('{}'); }
$d = json_decode(file_get_contents('php://input', false, null, 0, 4000), true);
if (!is_array($d)) $d = $_POST;
$f = function ($k, $n = 120) use ($d) {
  $v = isset($d[$k]) ? (string)$d[$k] : '';
  $v = preg_replace('/[\x00-\x1F\x7F]+/u', ' ', $v);
  return mb_substr(trim($v), 0, $n);
};
if ($f('hp') !== '') exit('{"ok":true}');
$phone = preg_replace('/\D/', '', $f('phone', 20));
if (strlen($phone) === 11 && ($phone[0] === '7' || $phone[0] === '8')) $phone = substr($phone, 1);
if (strlen($phone) !== 10 || $phone[0] !== '7') exit('{"ok":false}');
$phone = '+7 ' . substr($phone, 0, 3) . ' ' . substr($phone, 3, 3) . ' ' . substr($phone, 6, 2) . ' ' . substr($phone, 8, 2);
$file = __DIR__ . '/_wbc_leads.php';
if (!file_exists($file)) file_put_contents($file, "<?php http_response_code(404); exit; ?>\n");
if (filesize($file) > 5000000) exit('{"ok":false}');
$tail = @file($file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) ?: [];
foreach (array_slice($tail, -20) as $l) {
  $r = json_decode($l, true);
  if (is_array($r) && ($r[3] ?? '') === $phone && time() - strtotime($r[0]) < 600) exit('{"ok":true}');
}
$row = [date('Y-m-d H:i:s'), $f('city', 30), $f('tech', 60), $phone, $f('name', 80), $f('src', 40), $f('page', 100)];
file_put_contents($file, json_encode($row, JSON_UNESCAPED_UNICODE) . "\n", FILE_APPEND | LOCK_EX);
echo '{"ok":true}';
