<?php
// wbcagency.kz: таблица заявок со страниц Алматы / Караганды. Доступ только по секретной ссылке (?k=...), хранится хэш ключа.
date_default_timezone_set('Asia/Almaty');
header('Cache-Control: no-store');
header('X-Robots-Tag: noindex, nofollow');
if (!hash_equals('a2725603a66c82a5be97e41184a3df7d791faff8787a288ecd2ea5d0cee6dd54', hash('sha256', (string)($_GET['k'] ?? '')))) { http_response_code(404); exit; }
$rows = [];
$file = __DIR__ . '/_wbc_leads.php';
if (file_exists($file)) foreach (array_slice(file($file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES), 1) as $l) { $r = json_decode($l, true); if (is_array($r)) $rows[] = $r; }
$rows = array_reverse($rows);
$head = ['Дата и время', 'Город', 'Техника', 'Телефон', 'Имя / район', 'Источник', 'Страница'];
if (isset($_GET['csv'])) {
  header('Content-Type: text/csv; charset=utf-8'); header('Content-Disposition: attachment; filename="zayavki-goroda-' . date('Y-m-d') . '.csv"');
  $o = fopen('php://output', 'w'); fwrite($o, "\xEF\xBB\xBF"); fputcsv($o, $head, ';'); foreach ($rows as $r) fputcsv($o, $r, ';'); exit;
}
if (isset($_GET['json'])) { header('Content-Type: application/json; charset=utf-8'); echo json_encode($rows, JSON_UNESCAPED_UNICODE); exit; }
$h = fn($s) => htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); $k = $h($_GET['k']);
?><!doctype html><html lang="ru"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex,nofollow">
<title>Заявки — Алматы и Караганда</title><style>body{font:15px/1.4 -apple-system,Segoe UI,Roboto,sans-serif;margin:0;background:#f5f7fb;color:#111}.w{padding:16px;max-width:1100px;margin:auto}
a.b{display:inline-block;background:#0b1d4d;color:#fff;padding:8px 14px;border-radius:6px;text-decoration:none;margin:0 8px 14px 0}table{width:100%;border-collapse:collapse;background:#fff}
th,td{padding:9px 10px;border-bottom:1px solid #e5e7eb;text-align:left}th{background:#eef2f7}@media(max-width:700px){thead{display:none}tr{display:block;border-bottom:1px solid #ddd;padding:8px 0}td{display:block;border:0;padding:2px 10px}td:before{content:attr(data-l)": ";color:#888}}</style>
</head><body><div class="w"><h1>Заявки — Алматы и Караганда</h1><p>Всего: <?= count($rows) ?>. Новые сверху.</p>
<a class="b" href="?k=<?= $k ?>">Обновить</a><a class="b" href="?k=<?= $k ?>&csv=1">Скачать в Excel</a>
<table><thead><tr><?php foreach (array_slice($head, 0, 5) as $c) echo '<th>' . $h($c) . '</th>'; ?></tr></thead><tbody>
<?php if (!$rows) echo '<tr><td colspan="5">Пока заявок нет.</td></tr>';
foreach ($rows as $r) { echo '<tr>'; foreach (array_slice($r, 0, 5) as $i => $c) { $v = $h($c);
  if ($i == 3) { $n = preg_replace('/\D/', '', (string)$c); $v = '<a href="https://wa.me/' . $n . '" target="_blank">' . $v . '</a> · <a href="tel:+' . $n . '">позвонить</a>'; }
  echo '<td data-l="' . $h($head[$i]) . '">' . $v . '</td>'; } echo '</tr>'; } ?>
</tbody></table></div></body></html>
