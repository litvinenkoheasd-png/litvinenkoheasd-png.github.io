<?php
// Учёт нажатий на кнопки «Позвонить» / WhatsApp на страницах wbcagency.kz с источником визита
// (поиск Google, реклама Google, 2ГИС, прямой заход...). Запись — POST с сайта, чтение — GET ?k=<ключ>.
// Данные лежат вне httpdocs (или в закрытой папке), по одной JSON-строке на нажатие.
const KEY_SHA256 = 'dd9c8138572dec5ba07b2746ff9c299760ea8d8fc9c23de34aaa6e3f283b3f25';

function store_path() {
    $outside = dirname(__DIR__) . '/wbc-data';
    if (is_dir($outside) || @mkdir($outside, 0750)) {
        if (is_writable($outside)) return $outside . '/clicks.log';
    }
    $inside = __DIR__ . '/.wbc-data';
    if (!is_dir($inside)) { @mkdir($inside, 0750); @file_put_contents($inside . '/.htaccess', "Require all denied\nDeny from all\n"); }
    return $inside . '/clicks.log';
}
function clean($v, $n) { return mb_substr(preg_replace('/[\x00-\x1f]/u', '', (string)$v), 0, $n); }

header('Cache-Control: no-store');
header('X-Robots-Tag: noindex, nofollow');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $d = json_decode(file_get_contents('php://input', false, null, 0, 4000), true);
    if (!is_array($d)) { http_response_code(204); exit; }
    $type = in_array($d['t'] ?? '', ['tel', 'wa'], true) ? $d['t'] : null;
    if (!$type) { http_response_code(204); exit; }
    $row = [
        'ts'   => gmdate('c'),
        't'    => $type,
        'page' => clean($d['p'] ?? '', 200),
        'src'  => clean($d['s'] ?? 'unknown', 40),
        'ref'  => clean($d['r'] ?? '', 80),
        'land' => clean($d['l'] ?? '', 200),
        'ua'   => (preg_match('/Mobile|Android|iPhone/i', $_SERVER['HTTP_USER_AGENT'] ?? '') ? 'mobile' : 'desktop'),
        'v'    => substr(hash('sha256', ($_SERVER['REMOTE_ADDR'] ?? '') . gmdate('Y-m-d') . KEY_SHA256), 0, 10),
    ];
    if (preg_match('/bot|crawl|spider|headless/i', $_SERVER['HTTP_USER_AGENT'] ?? '')) { http_response_code(204); exit; }
    @file_put_contents(store_path(), json_encode($row, JSON_UNESCAPED_UNICODE) . "\n", FILE_APPEND | LOCK_EX);
    http_response_code(204);
    exit;
}

if (!hash_equals(KEY_SHA256, hash('sha256', (string)($_GET['k'] ?? '')))) { http_response_code(404); exit; }
$days = max(1, min(400, (int)($_GET['days'] ?? 30)));
$since = time() - $days * 86400;
$rows = [];
$f = store_path();
if (is_file($f)) {
    foreach (file($f, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) as $line) {
        $r = json_decode($line, true);
        if ($r && strtotime($r['ts']) >= $since) $rows[] = $r;
    }
}
header('Content-Type: application/json; charset=utf-8');
if (($_GET['raw'] ?? '') === '1') { echo json_encode($rows, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT); exit; }
$agg = ['days' => $days, 'total' => count($rows), 'by_source' => [], 'by_page' => [], 'by_day' => []];
foreach ($rows as $r) {
    $agg['by_source'][$r['src']][$r['t']] = ($agg['by_source'][$r['src']][$r['t']] ?? 0) + 1;
    $agg['by_page'][$r['page']][$r['src']][$r['t']] = ($agg['by_page'][$r['page']][$r['src']][$r['t']] ?? 0) + 1;
    $day = substr($r['ts'], 0, 10);
    $agg['by_day'][$day][$r['src']] = ($agg['by_day'][$day][$r['src']] ?? 0) + 1;
}
ksort($agg['by_day']);
echo json_encode($agg, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
