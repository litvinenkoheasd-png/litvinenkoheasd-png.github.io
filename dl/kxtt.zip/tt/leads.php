<?php
// KRYTEX / TikTok: таблица заявок со страницы /tt/. Доступ только по секретной ссылке (?k=...), хранится хэш ключа.
date_default_timezone_set('Asia/Almaty');
header('Cache-Control: no-store');
header('X-Robots-Tag: noindex, nofollow');
if (!hash_equals('10862f59a72d70e69968a8e9519ea94a711b0dc81abfdf82f70da02aa958fae1', hash('sha256', (string)($_GET['k'] ?? '')))) { http_response_code(404); exit; }
$rows = [];
$file = __DIR__ . '/_leads.php';
if (file_exists($file)) {
  foreach (array_slice(file($file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES), 1) as $l) {
    $r = json_decode($l, true); if (is_array($r)) $rows[] = $r;
  }
}
$rows = array_reverse($rows);
$head = ['Дата и время', 'Имя', 'Телефон', 'Автомобиль', 'Что интересует', 'Источник', 'ttclid', 'Страница'];
if (isset($_GET['csv'])) {
  header('Content-Type: text/csv; charset=utf-8');
  header('Content-Disposition: attachment; filename="krytex-tiktok-zayavki-' . date('Y-m-d') . '.csv"');
  $o = fopen('php://output', 'w'); fwrite($o, "\xEF\xBB\xBF");
  fputcsv($o, $head, ';'); foreach ($rows as $r) fputcsv($o, $r, ';'); exit;
}
if (isset($_GET['json'])) { header('Content-Type: application/json; charset=utf-8'); echo json_encode($rows, JSON_UNESCAPED_UNICODE); exit; }
$h = fn($s) => htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8');
$k = $h($_GET['k']);
$today = 0; foreach ($rows as $r) if (substr($r[0], 0, 10) === date('Y-m-d')) $today++;
?><!doctype html><html lang="ru"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="robots" content="noindex,nofollow"><title>KRYTEX — заявки из TikTok</title>
<style>body{font:15px/1.4 -apple-system,Segoe UI,Roboto,sans-serif;margin:0;background:#0b0b0d;color:#eee}
.w{padding:16px;max-width:1100px;margin:auto}h1{font-size:20px;margin:8px 0 4px}.m{color:#999;margin-bottom:14px}
a.b{display:inline-block;background:#e8e8e8;color:#111;padding:8px 14px;border-radius:6px;text-decoration:none;margin:0 8px 14px 0}
table{width:100%;border-collapse:collapse;background:#141418}th,td{padding:9px 10px;border-bottom:1px solid #26262c;text-align:left;vertical-align:top}
th{color:#aaa;font-weight:600;position:sticky;top:0;background:#1b1b21}td a{color:#8fd18f}
@media(max-width:700px){thead{display:none}tr{display:block;border-bottom:1px solid #333;padding:8px 0}td{display:block;border:0;padding:2px 10px}td:before{content:attr(data-l)": ";color:#888}}
</style></head><body><div class="w"><h1>KRYTEX — заявки из TikTok</h1>
<div class="m">Всего: <?= count($rows) ?>, сегодня: <?= $today ?>. Новые сверху. Нажмите на номер — откроется WhatsApp.</div>
<a class="b" href="?k=<?= $k ?>">Обновить</a><a class="b" href="?k=<?= $k ?>&csv=1">Скачать в Excel</a>
<table><thead><tr><?php foreach (array_slice($head, 0, 5) as $c) echo '<th>' . $h($c) . '</th>'; ?></tr></thead><tbody>
<?php if (!$rows) echo '<tr><td colspan="5">Пока заявок нет.</td></tr>';
foreach ($rows as $r) { echo '<tr>';
  foreach (array_slice($r, 0, 5) as $i => $c) {
    $v = $h($c);
    if ($i == 2) { $n = preg_replace('/\D/', '', (string)$c); $v = '<a href="https://wa.me/' . $n . '" target="_blank">' . $v . '</a> · <a href="tel:+' . $n . '">позвонить</a>'; }
    echo '<td data-l="' . $h($head[$i]) . '">' . $v . '</td>';
  }
  echo '</tr>'; } ?>
</tbody></table></div></body></html>
